<?php
session_start();
$user = $_SESSION['user'];
// echo $user;
if ($user == "") {
?>
  <script>
    document.location = '../index.php';
    </script>
    <?php
} else {
    include "boot.php";
?>

    <!-- ini navbar -->

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ryan12rpl3</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

  
    <nav class="navbar navbar-expand-lg" style="background-color:#6CBF84">
  <div class="container-fluid">
  <a class="navbar-brand text-light" href="#"><i><b><i class="bi bi-person-circle"></i>  BUKU TAMU DESA</b></i></a>
         
      <form class="d-flex " role="search" method="GET" action="tampil.php" target="konten">
        <input class="form-control me-2 " type="search" name="q" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Cari</button>
      </form>
    </div>
  </div>
</nav>
    <!-- tutup navbar -->


  </head>
  <body>


    <!-- ini halaman -->

  <div class="row mt-4 ">
    <div class="col-2">
    <ul class="list-group">
        <a href="input.php" target="konten">
             <li class="list-group-item "><i class="bi bi-clipboard2-plus-fill"></i> Input data</li>
             </a>
             <a href="tampil.php" target="konten">
             <li class="list-group-item"><i class="bi bi-calendar-check-fill"></i> Data Tamu</li>
             </a>
             <a href="rekap.php" target="konten">
             <li class="list-group-item"><i class="bi bi-printer-fill"></i> Rekap</li>
             </a>
             <a href="logout.php">
             <li class="list-group-item"><i class="bi bi-arrow-left-circle-fill"></i> logout</li>
             </a>
            
</ul>
</div>

    <div class="col ">
   <iframe src="" name="konten" frameborder="0" width="100%" height="800"></iframe>
    </div>
    <!-- tutup halaman -->
  </div>
  </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>
<?php
}
?>
