<?php
$konek=new mysqli ("localhost","root","","tamudesa_ryan")
?>